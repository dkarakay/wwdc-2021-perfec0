/*
 Welcome to the "Perfect0"!
 
 Pefect0 is a game to:
 1️⃣- Entertain people,
 2️⃣- Support them to practice more,
 3️⃣- Show how easy math is,
 4️⃣- Demonstrate how easy four operations are,
 5️⃣- Force people to do multitasking
 
 It is a PERFECT game for everyone!
 
 HOW TO PLAY❓
 👉🏻 Check remaining number on the bottom right, you need to decrease it to reach 0️⃣
 👉🏼 Remove undesirable numbers or operations by clicking them.
 👉🏽 Let one of the numbers or operations reach the ground. This becomes your operation.
 👉🏾 You are able to see your operations, in the operation bar on the bottom left.
 👉🏿 Your operation result will be decreased from the remaining number.
 👉 Keep going until you reach perfect 0 🎉
 
 PLAY NOW ▶️:
 Just click "Run My Code" button!
 To have a better performance, you should click "Run Options" button and disable "Enable results". 
 
 Have fun becoming Perfect0! 
 
 THANKS TO 😊 
 My family,
 My brother (Cem Karakay),
 
 For Art:
 - Colored Spheres (athile)
 - Kenney (Puzzle Pack)
 - Click icon (icon8)
 - Background (bevouliin.com)
 
 For Sound Effects:
 - Failure 2 (Leszek_Szary)
 - Button Selected (StavSounds)
 - Grand Entrance Intro (metrostock99)
 - Removing a Cap from an Asthma Inhaler (Natty23)
 
 For Background Music:
 - Happy Arcade Tune (rezoner)

 OpenGameArt
 FreeSound
 
 
 Deniz Karakay
 */


import PlaygroundSupport
import UIKit
import SwiftUI
import SpriteKit

let skView = SKView(frame: .zero)

// Tutorial View with SwiftUI
struct TutorialView: View {
    @State private var selectedTab = 0
    let numTabs = 10
    
    var body: some View {
        ZStack {
            Color.black
                .ignoresSafeArea()
            Image(uiImage: #imageLiteral(resourceName: "layer-1.png"))
                .resizable()
                .scaledToFill()                
                .opacity(0.4)
                .frame(width: 500, height:900)
            
        TabView(selection: $selectedTab){
            
            // Welcome Screen 
            VStack(spacing: 20){
                Image(uiImage: #imageLiteral(resourceName: "sphere-11.png"))
                    .resizable()
                    .frame(width: 80, height: 80)
                    .animation(.linear(duration: 1))
                
                Text("Welcome to Perfect0!")
                    .bold()
                    .foregroundColor(Color.white)
                    .font(.system(size:50))
                    .animation(.easeIn(duration: 1))
                
                Text("Swipe left or click Next for tutorial")
                    .foregroundColor(Color.white)
                    .font(.system(size:25))
                    .animation(.easeIn(duration: 1))
            }.tag(0)
            
            // 2nd Tab View
            VStack(spacing: 20){
                Image(uiImage: #imageLiteral(resourceName: "sphere-11.png"))
                    .resizable()
                    .frame(width: 80, height: 80)
                    .animation(.linear(duration: 1))
                
                Text("Math is easier with Perfect0!")
                    .bold()
                    .foregroundColor(Color.white)
                    .font(.system(size:35))
                    .animation(.easeIn(duration: 1))
                
                Text("Perfect0 aims not only to entertain you,")
                    .foregroundColor(Color.white)
                    .font(.system(size:25))
                    .animation(.easeIn(duration: 1))
                Text("but also help you to calculate fast!")
                    .foregroundColor(Color.white)
                    .font(.system(size:25))
                    .animation(.easeIn(duration: 1))
            }.tag(1)
            
            // 3rd Tab View
            VStack(spacing: 20){
                Text("What are those 4 operations?")
                    .bold()
                    .foregroundColor(Color.white)
                    .font(.system(size:35))
                    .animation(.easeIn(duration: 1))
                HStack{ 
                Text("Addition: ")
                    .bold()
                    .foregroundColor(Color.white)
                    .font(.system(size:25))
                    .animation(.easeIn(duration: 1))
                    Image(uiImage:#imageLiteral(resourceName: "addition.png"))
                        .resizable()
                        .frame(width: 50, height: 50)
                        .animation(.linear(duration: 1))
                }
                HStack{ 
                    Text("Subtraction: ")
                        .bold()
                        .foregroundColor(Color.white)
                        .font(.system(size:25))
                        .animation(.easeIn(duration: 1))
                    Image(uiImage:#imageLiteral(resourceName: "subtraction.png"))
                        .resizable()
                        .frame(width: 50, height: 50)
                        .animation(.linear(duration: 1))
                }
                HStack{ 
                    Text("Multiplication: ")
                        .bold()
                        .foregroundColor(Color.white)
                        .font(.system(size:25))
                        .animation(.easeIn(duration: 1))
                    Image(uiImage:#imageLiteral(resourceName: "multiplication.png"))
                        .resizable()
                        .frame(width: 50, height: 50)
                        .animation(.linear(duration: 1))
                }
                HStack{ 
                    Text("Division: ")
                        .bold()
                        .foregroundColor(Color.white)
                        .font(.system(size:25))
                        .animation(.easeIn(duration: 1))
                    Image(uiImage:#imageLiteral(resourceName: "division.png"))
                        .resizable()
                        .frame(width: 50, height: 50)
                        .animation(.linear(duration: 1))
                }
            }.tag(2)

            // 4th Tab View
            VStack(spacing: 20){
                Text("How to play Perfect0?")
                    .bold()
                    .foregroundColor(Color.white)
                    .font(.system(size:25))
                    .animation(.easeIn(duration: 1))
                Image(uiImage:#imageLiteral(resourceName: "number.png"))
                    .resizable()
                    .frame(width: 270, height: 480)
                    .animation(.linear(duration: 1))
                Text("You are trying to decrease the number with blue.")
                    .foregroundColor(Color.white)
                        .font(.system(size:20))
                        .animation(.easeIn(duration: 1))
                Text("Decrease 50 to 0 by using math operations 🤓")
                    .foregroundColor(Color.white)
                    .font(.system(size:20))
                    .animation(.easeIn(duration: 1))
                    
            }.tag(3).offset(x: 0, y: -60)
            
            // 5th Tab View
            VStack(spacing: 20){
                Text("How to play Perfect0?")
                    .bold()
                    .foregroundColor(Color.white)
                    .font(.system(size:25))
                    .animation(.easeIn(duration: 1))
                Image(uiImage:#imageLiteral(resourceName: "balls.png"))
                    .resizable()
                    .frame(width: 270, height: 480)
                    .animation(.linear(duration: 1))
                Text("These are balls with numbers to use in your operations.")
                    .foregroundColor(Color.white)
                    .font(.system(size:20))
                    .animation(.easeIn(duration: 1))
                Text("Leave one of the colored balls to reach the ground 🤓")
                    .foregroundColor(Color.white)
                    .font(.system(size:20))
                    .animation(.easeIn(duration: 1))
                
            }.tag(4).offset(x: 0, y: -60)
            
            // 6th Tab View
            VStack(spacing: 20){
                Text("How to play Perfect0?")
                    .bold()
                    .foregroundColor(Color.white)
                    .font(.system(size:25))
                    .animation(.easeIn(duration: 1))
                Image(uiImage:#imageLiteral(resourceName: "click.png"))
                    .resizable()
                    .frame(width: 270, height: 480)
                    .animation(.linear(duration: 1))
                Text("Remove undesirable numbers by clicking them 👈")
                    .foregroundColor(Color.white)
                    .font(.system(size:20))
                    .animation(.easeIn(duration: 1))
                Text("You can see the number reaches ground in the operation bar 👀")
                    .foregroundColor(Color.white)
                    .font(.system(size:20))
                    .animation(.easeIn(duration: 1))
                
            }.tag(5).offset(x: 0, y: -60)
        
            // 7th Tab View
            VStack(spacing: 20){
                Text("How to play Perfect0?")
                    .bold()
                    .foregroundColor(Color.white)
                    .font(.system(size:25))
                    .animation(.easeIn(duration: 1))
                Image(uiImage:#imageLiteral(resourceName: "operation click.png"))
                    .resizable()
                    .frame(width: 270, height: 480)
                    .animation(.linear(duration: 1))
                Text("You need to remove undesirable operations just like numbers.")
                    .foregroundColor(Color.white)
                    .font(.system(size:20))
                    .animation(.easeIn(duration: 1))
                Text("In this case, your operation is addition (+)")
                    .foregroundColor(Color.white)
                    .font(.system(size:20))
                    .animation(.easeIn(duration: 1))
                
            }.tag(6).offset(x: 0, y: -60)
            
            // 8th Tab View
            VStack(spacing: 20){
                Text("How to play Perfect0?")
                    .bold()
                    .foregroundColor(Color.white)
                    .font(.system(size:25))
                    .animation(.easeIn(duration: 1))
                Image(uiImage:#imageLiteral(resourceName: "second ball.png"))
                    .resizable()
                    .frame(width: 270, height: 480)
                    .animation(.linear(duration: 1))
                Text("Remove undesirable numbers again by clicking them 👈")
                    .foregroundColor(Color.white)
                    .font(.system(size:20))
                    .animation(.easeIn(duration: 1))
                Text("You can see the second number and final result in the operation bar 👀")
                    .foregroundColor(Color.white)
                    .font(.system(size:20))
                    .animation(.easeIn(duration: 1))
                
            }.tag(7).offset(x: 0, y: -60)
            // 9th Tab View
            VStack(spacing: 20){
                Text("How to play Perfect0?")
                    .bold()
                    .foregroundColor(Color.white)
                    .font(.system(size:25))
                    .animation(.easeIn(duration: 1))
                Image(uiImage:#imageLiteral(resourceName: "final.png"))
                    .resizable()
                    .frame(width: 270, height: 480)
                    .animation(.linear(duration: 1))
                Text("If you complete one operation,")
                    .foregroundColor(Color.white)
                    .font(.system(size:20))
                    .animation(.easeIn(duration: 1))
                Text("the remaining value will be decreased by your result 🤩")
                    .offset(x:0,y:-5)
                    .foregroundColor(Color.white)
                    .font(.system(size:20))
                    .animation(.easeIn(duration: 1))
                
            }.tag(8).offset(x: 0, y: -60)
            
            // 10th Tab View
            VStack(spacing: 20){
                Text("You are ready to go 🥳")
                    .bold()
                    .foregroundColor(Color.white)
                    .font(.system(size:35))
                    .animation(.easeIn(duration: 1))
                
                Text("Be fast, be practical and reach perfect 0!")
                    .padding()
                    .foregroundColor(Color.white)
                    .font(.system(size:23))
                    .animation(.easeIn(duration: 1))
            }.tag(9)
        }.tabViewStyle(PageTabViewStyle())
            HStack{ 
                if selectedTab > 0 { 
                    Button(action: {
                        selectedTab = (selectedTab - 1) % numTabs
                    }){
                        Text("Back")
                            .font(.system(size: 18, design: .rounded))
                            .padding()
                            .foregroundColor(.white)
                            .background(Color.gray)
                            .cornerRadius(10.0)
                            .padding()
                        
                    }.offset(y: 330)
                }
            Button(action: {
                if selectedTab == numTabs-1{
                    UserDefaults.standard.set(true, forKey: "firstTime")
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5){
                        let gameScene = GameScene(size: CGSize(width: 720, height: 1280))
                        gameScene.scaleMode = .aspectFit
                        skView.presentScene(gameScene)
                        skView.preferredFramesPerSecond = 60
                        
                        PlaygroundPage.current.liveView = skView;
                    }
                }else{
                    selectedTab = (selectedTab + 1) % numTabs
                }
            })
            {
                if selectedTab == numTabs-1{
                    Text("Let's play!")
                        .padding()
                        .foregroundColor(.white)
                        .background(Color.orange)
                        .font(.system(size: 18, design: .rounded))
                        .cornerRadius(10.0)
                        .padding()
                }else{ 
                Text("Next")
                    .font(.system(size: 18, design: .rounded))
                    .padding()
                    .foregroundColor(.white)
                    .background(Color.blue)
                    .cornerRadius(10.0)
                    .padding()
                }
                
            }.offset(y: 330)
            }
        }
    }
}


PlaygroundPage.current.setLiveView(TutorialView())

