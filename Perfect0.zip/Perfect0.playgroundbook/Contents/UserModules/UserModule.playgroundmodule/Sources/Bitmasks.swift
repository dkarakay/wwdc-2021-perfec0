// Collision Detection
public struct Bitmasks{
    static let detector: UInt32 = 1 << 1
    static let firstNumber: UInt32 = 1 << 2
    static let secondNumber: UInt32 = 1 << 3
    static let operation: UInt32 = 1 << 4
    static let world: UInt32 = 1 << 5
}

