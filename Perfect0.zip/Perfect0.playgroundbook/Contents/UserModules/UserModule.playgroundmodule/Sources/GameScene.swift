import SpriteKit
import AVFoundation

public var minX: CGFloat = 0.0
public var minY: CGFloat = 0.0
public var midX: CGFloat = 0.0
public var midY: CGFloat = 0.0
public var maxX: CGFloat = 0.0
public var maxY: CGFloat = 0.0

public class GameScene: SKScene, SKPhysicsContactDelegate{
    
    var currentRm: Int!
    var firstNumber: Int!
    var remainingNumber: Int!
    var secondNumber: Int!
    var result: Int!
    
    var speedOfItems: CGFloat = 1.5
    var operationType: String!
    
    var numberWait: SKAction?
    var numberAction: SKAction?
    
    var detector: SKSpriteNode!
    var bg:SKSpriteNode!
    
    var remainingLabel:SKLabelNode!
    var firstNumberLabel:SKLabelNode!
    var equalLabel:SKLabelNode!
    var secondNumberLabel:SKLabelNode!
    var operationLabel:SKLabelNode!
    var endingLabel:SKLabelNode!
    var levelLabel:SKLabelNode!
    var extraLabel:SKLabelNode!
    
    var firstNumberNodes = [SKSpriteNode]()
    var secondNumberNodes = [SKSpriteNode]()
    var operationNodes = [SKSpriteNode]()
    
    var firstNumbers = [Int]()
    var secondNumbers = [Int]()
    var operations = [Int]()
    
    var backgroundMusic: AVAudioPlayer?
    var failEffect: AVAudioPlayer?
    var successEffect: AVAudioPlayer?
    var selectEffect: AVAudioPlayer?
    var removeEffect: AVAudioPlayer?
    
    
    var numberTime: TimeInterval = 1.7
    
    var endingEffect = true
    var generateFirstNumber = true
    var generateSecondNumber = false
    var generateOperations = false
    var gameOver = false
    
    public override func didMove(to view: SKView) {
        // First Time Check
        if UserDefaults.standard.bool(forKey: "firstTime") == true {
            currentRm = 50
            UserDefaults.standard.set(currentRm, forKey: "remaining")
            UserDefaults.standard.set(false, forKey: "firstTime")
        }else{
            currentRm = UserDefaults.standard.integer(forKey: "remaining")
        }
        
        // Getting the remaining number
        remainingNumber = currentRm
        
        
        // Background Music
        let path = Bundle.main.path(forResource: "happy.mp3", ofType: nil)!
        let url = URL(fileURLWithPath: path)
        
        do{
            backgroundMusic = try AVAudioPlayer(contentsOf: url)
            backgroundMusic?.volume = 0.2
            backgroundMusic?.play()
        }catch{
            
        }
        
        // Positions of frame
        midY = frame.midY
        midX = frame.midX
        minX = frame.minX
        minY = frame.minY
        maxX = frame.maxX
        maxY = frame.maxY
        
        physicsBody = SKPhysicsBody(edgeLoopFrom: frame)
        physicsBody?.friction = 0.0
        physicsBody?.categoryBitMask = Bitmasks.world
        physicsWorld.contactDelegate = self
        
        // Remaining Text
        remainingLabel = SKLabelNode(text: "\(remainingNumber!)")
        remainingLabel.fontSize = 50.0
        remainingLabel.fontName = "Futura"
        remainingLabel.position = CGPoint(x: maxX*0.9, y: maxY*0.03)
        remainingLabel.zPosition = 5
        remainingLabel.fontColor = .white
        addChild(remainingLabel)
        
        
        // First Number
        firstNumberLabel = SKLabelNode(text: "")
        firstNumberLabel.fontSize = 40.0
        firstNumberLabel.fontName = "Futura"
        firstNumberLabel.position = CGPoint(x: maxX*0.07, y: maxY*0.03)
        firstNumberLabel.zPosition = 5
        firstNumberLabel.fontColor = .white
        addChild(firstNumberLabel)
        
        // Operation Text
        operationLabel = SKLabelNode(text: "")
        operationLabel.fontSize = 40.0
        operationLabel.fontName = "Helvetica"
        operationLabel.position = CGPoint(x: maxX*0.14, y: maxY*0.03)
        operationLabel.zPosition = 5
        operationLabel.fontColor = .white
        addChild(operationLabel)
        
        // Second Number
        secondNumberLabel = SKLabelNode(text: "")
        secondNumberLabel.fontSize = 40.0
        secondNumberLabel.fontName = "Futura"
        secondNumberLabel.position = CGPoint(x: maxX*0.21, y: maxY*0.03)
        secondNumberLabel.zPosition = 5
        secondNumberLabel.fontColor = .white
        addChild(secondNumberLabel)
        
        // Equal Text
        equalLabel = SKLabelNode(text: "")
        equalLabel.fontSize = 40.0
        equalLabel.fontName = "Futura"
        equalLabel.position = CGPoint(x: maxX*0.32, y: maxY*0.03)
        equalLabel.zPosition = 5
        equalLabel.fontColor = .white
        addChild(equalLabel)
        
        
        // Detector
        detector = SKSpriteNode(texture: SKTexture(image:#imageLiteral(resourceName: "layer-2.png")), color: .clear, size: CGSize(width: size.width, height: size.height*0.05))
        detector.position = CGPoint(x: midX, y: minY + detector.size.height*2.5)
        detector.alpha = 0.7
        addChild(detector)
        
        detector.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: maxX, height: detector.size.height))
        detector.physicsBody?.isDynamic = false
        detector.physicsBody?.categoryBitMask = Bitmasks.detector
        detector.physicsBody?.contactTestBitMask = Bitmasks.firstNumber
        detector.physicsBody?.contactTestBitMask = Bitmasks.secondNumber
        
        
        //Background
        bg = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "layer-1.png")))
        bg.zPosition = -10;
        bg.setScale(0.8)
        bg.alpha = 0.7
        bg.position = CGPoint(x: midX, y: maxY*0.6)
        addChild(bg)
        
        
        // Loop code
        numberWait = SKAction.wait(forDuration: numberTime)
        numberAction = SKAction.run {
            if self.remainingNumber > 0 {
                var randomInt = Int.random(in: 1...4)
                
                // Generate first number ball (3x)
                if self.generateFirstNumber == true{
                    for i in 1 ... 3 {
                        // Number generation
                        self.numberGenerator(remaining: self.remainingNumber)
                        self.create_numbers(posX: maxX*0.25*CGFloat(i), posY: maxY, speed: self.speedOfItems, isFirst: true,number: self.firstNumbers[i-1], randomTexture: randomInt)
                    }
                    self.generateFirstNumber = false
                    
                    // Generate operation (3x)
                }else if self.generateOperations == true{
                    for i in 1 ... 3 {
                        self.create_operations(posX: maxX*0.25*CGFloat(i), posY: maxY, speed: self.speedOfItems, operationNumber: self.operations[i-1])
                    }
                    self.generateOperations = false
                    
                    // Generate second number ball(3x)
                }else if self.generateSecondNumber == true{
                    for i in 1 ... 3 {
                        self.create_numbers(posX: maxX*0.25*CGFloat(i), posY: maxY, speed: self.speedOfItems, isFirst: false,number:self.secondNumbers[i-1], randomTexture: randomInt)
                    }
                    self.generateSecondNumber = false
                }
                
                // Speed up the items
                self.speedOfItems += 0.03
                self.numberTime -= 0.4
                
                // If remaining is 0 or less than 0
            }else{
                if (self.remainingNumber == 0 && self.gameOver == false){
                    // Success, and open new level
                    self.showEndingMessage(endingType:0)
                    self.updateRemainingNumber(rm: self.currentRm + 50)
                    self.restartGame(isSuccessful: true)
                    self.numberTime = 50
                }else if (self.gameOver == false){
                    // Fail, and restart the game
                    self.showEndingMessage(endingType:2)
                    self.restartGame(isSuccessful: false)
                    self.numberTime = 50
                }
                self.gameOver = true
            }
        }
        run(SKAction.repeatForever(SKAction.sequence([numberWait!,numberAction!])))
        
    }
    // If collisions are started
    public func didBegin(_ contact: SKPhysicsContact) {
        if (contact.bodyA.categoryBitMask == Bitmasks.detector){
            for numberNode in firstNumberNodes{
                if(contact.bodyB.node == numberNode){
                    generateOperations = true
                    
                    if let label = numberNode.childNode(withName: "number") as? SKLabelNode {
                        if let tex:String? = label.text{
                            var returned =  Int(tex!) ?? 0
                            
                            firstNumber = returned
                            firstNumberLabel.text! = "\(firstNumber!)"
                            operationLabel.text! = ""
                            secondNumberLabel.text! = ""
                            equalLabel.text! = ""
                            
                            // Remove all firstNumberNodes
                            for numberNode in firstNumberNodes{
                                numberNode.removeAllActions()
                                numberNode.removeFromParent()
                            }
                            soundEffectPlayer(name: "select.mp3", situation: 2)
                            
                            firstNumberNodes.removeAll()
                            firstNumbers.removeAll()
                        }
                        
                    }
                    
                }
            }
                
                for operationNode in operationNodes{
                    if(contact.bodyB.node == operationNode){
                        generateSecondNumber = true
                        
                        if let label = operationNode.childNode(withName: "operation") as? SKLabelNode {
                            if let tex:String? = label.text{
                                operationType = tex!
                                operationLabel.text! = operationType
                                
                                // Remove all operationNodes
                                for operationNode in operationNodes{
                                    operationNode.removeAllActions()
                                    operationNode.removeFromParent()
                                }
                                soundEffectPlayer(name: "select.mp3", situation: 2)
                                
                                operationNodes.removeAll()
                                operations.removeAll()
                            }
                        }
                        
                    }
                }
                    for numberNode in secondNumberNodes{
                        if(contact.bodyB.node == numberNode){
                            generateFirstNumber = true
                            
                            if let label = numberNode.childNode(withName: "number") as? SKLabelNode {
                                if let tex:String? = label.text{
                                    var returned =  Int(tex!) ?? 0
                                    
                                    secondNumber = returned
                                    secondNumberLabel.text! = "\(secondNumber!)"
                                    
                                    switch operationType {
                                    case "+":
                                        result = firstNumber! + secondNumber!
                                        break
                                    case "-":
                                        result = firstNumber! - secondNumber!
                                        break
                                    case "x":
                                        result = firstNumber! * secondNumber!
                                        break
                                    case ":":
                                        // Division by zero solution
                                        if secondNumber == 0 {
                                            showEndingMessage(endingType: 1)
                                            restartGame(isSuccessful: false)
                                        }else{
                                            result = firstNumber! / secondNumber!
                                        }
                                        break
                                    default:
                                        result = 0
                                    }
                                    
                                    // Updating text
                                    equalLabel.text! = "= \(result!)"
                                    remainingNumber! -= result!
                                    remainingLabel.text = "\(remainingNumber!)"
                                    soundEffectPlayer(name: "select.mp3", situation: 2)
                                    
                                    
                                    // Remove all secondNumberNodes
                                    for numberNode in secondNumberNodes{
                                        numberNode.removeAllActions()
                                        numberNode.removeFromParent()
                                    }
                                    secondNumberNodes.removeAll()
                                    secondNumbers.removeAll()
                                }
                            }
                            
                        }
                    }
                }
    }
                
    // Touch screen events
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let touchLocation = touch.location(in: self)
        let touchedNodes = nodes(at: touchLocation)
        for node in touchedNodes {
            // Removing first number
            for numberNode in firstNumberNodes{
                if(node == numberNode){
                    soundEffectPlayer(name: "remove.mp3", situation: 3)
                    if let index = firstNumberNodes.firstIndex(of: numberNode) {
                        firstNumberNodes.remove(at: index)
                        
                    }
                    // If all firstNumber nodes removed, regenerate them
                    if firstNumberNodes.count == 0{
                        generateFirstNumber = true
                        generateOperations = false
                        generateSecondNumber = false
                        
                    }
                    numberNode.removeAllActions()
                    numberNode.removeFromParent()
                    
                }
                
            }
            // Removing operation object
            for operationNode in operationNodes{
                if(node == operationNode){
                    soundEffectPlayer(name: "remove.mp3", situation: 3)
                    if let index = operationNodes.firstIndex(of: operationNode) {
                        operationNodes.remove(at: index)
                        
                    }
                    // If all operation nodes removed, regenerate them
                    if operationNodes.count == 0{
                        generateFirstNumber = false
                        generateOperations = true
                        generateSecondNumber = false
                        
                    }
                    operationNode.removeAllActions()
                    operationNode.removeFromParent()
                    
                }
                
            }
            // Removing second number
            for numberNode in secondNumberNodes{
                if(node == numberNode){
                    soundEffectPlayer(name: "remove.mp3", situation: 3)
                    if let index = secondNumberNodes.firstIndex(of: numberNode) {
                        secondNumberNodes.remove(at: index)
                        
                    }
                    // If all secondNumber nodes removed, regenerate them
                    if secondNumberNodes.count == 0{
                        generateFirstNumber = false
                        generateOperations = false
                        generateSecondNumber = true
                        
                    }
                    numberNode.removeAllActions()
                    numberNode.removeFromParent()
                    
                }
                
            }
            
        }
        
    }
    // Generating random numbers according to remaining number and the operation
    func numberGenerator(remaining:Int){
        var first = 0
        var operation = 0
        var second = 0
        if(remaining > 0){
            if remaining > 199{
                first = Int.random(in: remaining/20...remaining/15)
                operation = Int.random(in: 1...3)
                switch operation {
                case 1:
                    second = Int.random(in: (remaining-first)/15...(remaining-first)/10)
                case 2:
                    second = Int.random(in: (remaining-first)/25...(remaining-first)/10)
                case 3:
                    second = Int.random(in: (remaining-first)/30...(remaining-first)/20)
                default:
                    second = Int.random(in: (remaining-first)/15...(remaining-first)/10)
                }
                
            }else if remaining > 99{
                first = Int.random(in: remaining/10...remaining/5)
                operation = Int.random(in: 1...3)
                switch operation {
                case 1:
                    second = Int.random(in: (remaining-first)/6...(remaining-first)/3)
                case 2:
                    second = Int.random(in: (remaining-first)/25...(remaining-first)/10)
                case 3:
                    second = Int.random(in: (remaining-first)/20...(remaining-first)/10)
                default:
                    second = Int.random(in: (remaining-first)/10...(remaining-first)/5)
                    
                }
                
            }else if remaining > 49{
                first = Int.random(in: remaining/8...remaining/4)
                operation = Int.random(in: 1...3)
                switch operation {
                case 1:
                    second = Int.random(in: (remaining-first)/5...(remaining-first)/3)
                case 2:
                    second = Int.random(in: (remaining-first)/15...(remaining-first)/5)
                case 3:
                    second = Int.random(in: (remaining-first)/16...(remaining-first)/8)
                case 4:
                    second = Int.random(in: (remaining-first)/16...(remaining-first)/12)
                default:
                    second = Int.random(in: (remaining-first)/5...(remaining-first)/3)
                    
                }
                
            }else if remaining > 19{
                first = Int.random(in: remaining/5...remaining/3)
                operation = Int.random(in: 1...5)
                switch operation {
                case 1:
                    second = Int.random(in: (remaining-first)/4...(remaining-first)/2)
                case 2:
                    second = Int.random(in: (remaining-first)/20...(remaining-first)/4)
                case 3:
                    second = Int.random(in: (remaining-first)/10...(remaining-first)/6)
                case 4:
                    second = Int.random(in: (remaining-first)/10...(remaining-first)/8)
                default:
                    second = Int.random(in: (remaining-first)/4...(remaining-first)/2)
                    
                }
                
            }else if remaining < 5{
                first = Int.random(in: 0...4)
                operation = Int.random(in: 1...5)
                second = Int.random(in: 1...3)
                
            }else{
                first = Int.random(in: 1...remaining)
                operation = Int.random(in: 1...5)
                if (remaining-first > 1){
                    switch operation {
                    case 1:
                        second = Int.random(in:0...(remaining-first))
                    case 2:
                        second = Int.random(in:0...(remaining-first)/2)
                    case 3:
                        second = Int.random(in: 0...(remaining/first))
                    case 4:
                        second = Int.random(in: 1...(remaining-first))
                    default:
                        second = Int.random(in:0...(remaining-first))
                        
                    }
                    
                }
                
            }
            // If the consecutive values are same
            if (first == firstNumbers.last) || (second == secondNumbers.last || operation == operations.last){
                numberGenerator(remaining: remaining)
                
            }
            // Add generated objects to lists to track and use them
            firstNumbers.append(first)
            secondNumbers.append(second)
            operations.append(operation)
            
        }
        
    }
    // Create and impulse the number object
    func create_numbers(posX: CGFloat, posY:CGFloat, speed: CGFloat, isFirst:Bool, number:Int, randomTexture: Int){
        let numberObject = SKSpriteNode(texture: SKTexture(image:#imageLiteral(resourceName: "sphere-02.png")), color: .clear, size: CGSize(width: size.width*0.15, height: size.width*0.15))
        
        let numberLabel = SKLabelNode(text: "\(number)")
        numberLabel.name = "number"
        numberLabel.fontSize = 40.0
        numberLabel.position = CGPoint(x: 0, y: -17)
        numberLabel.zPosition = 5
        numberLabel.fontName = "Futura"
        numberLabel.fontColor = .white
        
        numberObject.position = CGPoint(x: posX,y:posY)
        numberObject.physicsBody = SKPhysicsBody(circleOfRadius: numberObject.size.width)
        numberObject.physicsBody?.affectedByGravity = false
        numberObject.physicsBody?.friction = 0.0
        numberObject.physicsBody?.allowsRotation = false
        numberObject.physicsBody?.restitution = 1.1
        numberObject.physicsBody?.linearDamping = 0.0
        numberObject.physicsBody?.contactTestBitMask = Bitmasks.detector
        numberObject.physicsBody?.collisionBitMask = Bitmasks.detector
        
        // For first number
        if isFirst == true{
            
            switch randomTexture {
            case 1:
                numberObject.texture = SKTexture(image:#imageLiteral(resourceName: "sphere-11.png"))
            case 2:
                numberObject.texture = SKTexture(image:#imageLiteral(resourceName: "sphere-18.png"))
            case 3:
                numberObject.texture = SKTexture(image:#imageLiteral(resourceName: "sphere-16.png"))
            case 4:
                numberObject.texture = SKTexture(image:#imageLiteral(resourceName: "sphere-09.png"))
            default:
                numberObject.texture = SKTexture(image:#imageLiteral(resourceName: "sphere-11.png"))
                
            }
            numberObject.physicsBody?.categoryBitMask = Bitmasks.firstNumber
            firstNumberNodes.append(numberObject)
            
            
        // For second number
        }else{
            switch randomTexture {
            case 1:
                numberObject.texture = SKTexture(image:#imageLiteral(resourceName: "sphere-02.png"))
            case 2:
                numberObject.texture = SKTexture(image:#imageLiteral(resourceName: "sphere-08.png"))
            case 3:
                numberObject.texture = SKTexture(image:#imageLiteral(resourceName: "sphere-04.png"))
            case 4:
                numberObject.texture = SKTexture(image:#imageLiteral(resourceName: "sphere-06.png"))
            default:
                numberObject.texture = SKTexture(image:#imageLiteral(resourceName: "sphere-02.png"))
                
            }
            numberObject.physicsBody?.categoryBitMask = Bitmasks.secondNumber
            secondNumberNodes.append(numberObject)
            
        }
        numberObject.addChild(numberLabel)
        addChild(numberObject)
                    
        var dyComponent: CGFloat = 0
        var dxComponent: CGFloat = 0
                    
        dyComponent = (maxY)
        dxComponent = 0
        numberObject.physicsBody?.applyImpulse(CGVector(dx:dxComponent , dy: dyComponent * -0.15 * speed))
                    
    }
    // Create and impuls the operation object
    func create_operations(posX: CGFloat, posY:CGFloat, speed: CGFloat, operationNumber:Int){
        let operationObject = SKSpriteNode(texture:  SKTexture(image:#imageLiteral(resourceName: "element_blue_square_glossy.png")), color: .clear, size: CGSize(width: size.width*0.15, height: size.width*0.15))
        var operation = ""
        switch operationNumber {
        case 1:
            operation = "+"
            break
        case 2:
            operation = "-"
            break
        case 3:
            operation = "x"
            break
        case 4:
            operation = ":"
            break
        default:
            operation = "+"
            break
            
        }
                    
        let operationLabel = SKLabelNode(text:operation)
        operationLabel.name = "operation"
        operationLabel.fontSize = 60.0
        operationLabel.fontName = "Futura"
        operationLabel.position = CGPoint(x: 0, y: -17)
        operationLabel.zPosition = 5
        operationLabel.fontColor = .white
                    
        operationObject.position = CGPoint(x: posX,y:posY)
        operationObject.physicsBody = SKPhysicsBody(circleOfRadius: operationObject.size.width)
        operationObject.physicsBody?.affectedByGravity = false
        operationObject.physicsBody?.friction = 0.0
        operationObject.physicsBody?.allowsRotation = false
        operationObject.physicsBody?.restitution = 1.2
        operationObject.physicsBody?.linearDamping = 0.0
        operationObject.physicsBody?.categoryBitMask = Bitmasks.operation
        operationObject.physicsBody?.contactTestBitMask = Bitmasks.detector
        operationObject.physicsBody?.collisionBitMask = Bitmasks.detector
        
        operationObject.addChild(operationLabel)
        addChild(operationObject)
        operationNodes.append(operationObject)
                    
        var dyComponent: CGFloat = 0
        var dxComponent: CGFloat = 0
                    
        dyComponent = (maxY)
        operationObject.physicsBody?.applyImpulse(CGVector(dx:dxComponent , dy: dyComponent * -0.15 * speed))
        
    }
    func restartGame(isSuccessful:Bool){
        // Playing sound effect according to the status
        if isSuccessful{
            soundEffectPlayer(name: "success.mp3", situation: 0)
        }else{
            soundEffectPlayer(name: "fail.mp3", situation: 0)
            
        }
        backgroundMusic?.stop()
        endingEffect = false
        
        // Wait 4 second before restarting game
        DispatchQueue.main.asyncAfter(deadline: .now() + 4.0) {
            let newScene = GameScene(size: self.size)
            let animation = SKTransition.fade(withDuration: 1.0)
            newScene.scaleMode = self.scaleMode
            self.view?.presentScene(newScene,transition: animation)
            
        }
        
    }
    func updateRemainingNumber(rm: Int)-> Int{
        // Update remaining number for new levels
        let defaults = UserDefaults.standard
        let hs = defaults.integer(forKey: "remaining")
        defaults.set(rm, forKey: "remaining")
        return Int(defaults.integer(forKey: "remaining"))
        
    }
    func showEndingMessage(endingType:Int){
        // Changing alpha to move focus to ending label
        bg.alpha = 0.4
        firstNumberLabel.alpha = 0.5
        secondNumberLabel.alpha = 0.5
        operationLabel.alpha = 0.5
        equalLabel.alpha = 0.5
        remainingLabel.alpha = 0.5
                    
        let defaults = UserDefaults.standard
        let rem = defaults.integer(forKey: "remaining")
        
        // Ending Label
        endingLabel = SKLabelNode(text:"")
        endingLabel.fontSize = 60.0
        endingLabel.position = CGPoint(x: midX, y: maxY * 0.65)
        endingLabel.zPosition = 5
        endingLabel.fontName = "Futura"
        endingLabel.preferredMaxLayoutWidth = midX
        endingLabel.fontColor = .white
        addChild(endingLabel)
        
        // Level Label
        var levelNo = rem/50
        levelLabel = SKLabelNode(text:"Level \(levelNo) completed 🎉")
        levelLabel.fontSize = 60.0
        levelLabel.position = CGPoint(x: midX, y: maxY * 0.5)
        levelLabel.zPosition = 5
        levelLabel.fontName = "Futura"
        levelLabel.preferredMaxLayoutWidth = midX
        levelLabel.fontColor = .white
        addChild(levelLabel)
        
        // Extra Label
        extraLabel = SKLabelNode(text:"")
        extraLabel.fontSize = 60.0
        extraLabel.position = CGPoint(x: midX, y: maxY * 0.35)
        extraLabel.zPosition = 5
        extraLabel.fontName = "Futura"
        extraLabel.preferredMaxLayoutWidth = midX
        extraLabel.fontColor = .white
        addChild(extraLabel)
        
        switch endingType {
        case 0:
            endingLabel.text = "Perfect0! 🥳"
            levelLabel.text = "Level \(levelNo) completed 🎉"
        case 1:
            endingLabel.text = "Level \(levelNo) failed 😞"
            levelLabel.text = "Cannot divide 0 😕"
            extraLabel.text = "Try again!"
        case 2:
            endingLabel.text = "Level \(levelNo) failed 😞"
            levelLabel.text = "Less than 0 😕"
            extraLabel.text = "Try again!"
        default:
            endingLabel.text = ""
            
        }
        
        
        
    }
    // Sound effect player
    func soundEffectPlayer (name: String, situation: UInt32){
        let path = Bundle.main.path(forResource: name, ofType: nil)!
        let url = URL(fileURLWithPath: path)
        do{
            switch situation {
            case 0:
                //Fail sound effect
                failEffect = try AVAudioPlayer(contentsOf: url)
                
                // Check if ending effect has played before
                guard endingEffect else {return}
                failEffect?.play()
                failEffect?.volume = 0.7
                endingEffect = true
                break
                            
            case 1:
                
                // Check if ending effect has played before
                guard endingEffect else {return}
                // Success sound effect
                successEffect = try AVAudioPlayer(contentsOf: url)
                successEffect?.play()
                successEffect?.volume = 0.7
                endingEffect = true
                break
                            
            case 2:
                // Select sound Effect
                selectEffect = try AVAudioPlayer(contentsOf: url)
                selectEffect?.play()
                selectEffect?.volume = 0.7
                break
                            
            case 3:
                // Remove sound Effect
                removeEffect = try AVAudioPlayer(contentsOf: url)
                removeEffect?.play()
                removeEffect?.volume = 0.7
                break
            default:
                break
                
            }
            
        }catch{
            
        }
                
    }
    
}
        
